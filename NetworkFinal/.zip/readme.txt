To compile, it works just like the Talk Project did.

just type make,

and then ./server on one session
and ./client 127.0.0.1 on the other.
